
object HelloWorld {

  def main(arguments: Array[String]): Unit = {
    val integers: Array[Int] = Array(1, 2, 7, 3)
    println("my integers: " + integers.mkString(" +=+ "))
    println("Hello, world!!!!")
    println("Number of arguments: " + countArguments(arguments))
  }

  def countArguments(array: Array[String]): Int = {
    array.length
  }
}

