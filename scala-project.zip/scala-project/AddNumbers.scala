
object AddNumbers {

  def main(l: Array[String]) {
    m1(l)
  }

  //def xxx(): Int = "hi"

  def m1(list: Array[String]) {
    println(list(0).toInt + list(1).toInt)
  }

  def m2(list: Array[String]) = {
    val sum = list(0).toInt + list(1).toInt
    sum
  }

}
